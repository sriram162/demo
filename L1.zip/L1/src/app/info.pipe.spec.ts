import { InfoPipe } from './info.pipe';

describe('InfoPipe', () => {
  it('create an instance', () => {
    const pipe = new InfoPipe();
    expect(pipe).toBeTruthy();
  });
});
