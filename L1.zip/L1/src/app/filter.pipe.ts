import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(results : any,searchValue: string):any {
    if (searchValue===undefined){
      console.log(results);
      return results;
    }
else{
  return results.filter(
                           function(result:any){
                                       return result.Name.toLowerCase()
                                                   .includes(searchValue.toLowerCase());
                                               }
  )
}
  }

}
