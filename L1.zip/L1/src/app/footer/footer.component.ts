import { Component, OnInit } from '@angular/core';
//import { FormControl } from '@angular/forms';
import { DataService } from '../data.service';
import{FormGroup,FormControl,Validators}from'@angular/forms'
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
tabledata:any=[]
  constructor(private ds:DataService) { }
public response:any=[]
  ngOnInit(): void {
    this.ds.getUsers().subscribe((data)=>{
      this.response=data
console.log(this.response)
    })
  }
  userForm=new FormGroup({
    name:new FormControl(''),
    username:new FormControl(''),
    email:new FormControl('')
  });
  onSubmit(){
    this.tabledata.push(this.userForm.value);
    this.userForm.reset()
  
  }


}
