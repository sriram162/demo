import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coursedetails',
  templateUrl: './coursedetails.component.html',
  styleUrls: ['./coursedetails.component.css']
})
export class CoursedetailsComponent implements OnInit {

//showDuration(){
  //this._router.navigate(['duration'])
//}
  constructor() { }

  ngOnInit(): void {
  }

}
