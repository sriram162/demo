import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'keys'
})
export class InfoPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    console.log(Object.keys(value));

    return Object.keys(value);
    
    
  }
}
