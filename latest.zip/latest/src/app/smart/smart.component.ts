import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

import { DataService } from '../data.service';
import{InfoPipe}from '../info.pipe';


@Component({
  selector: 'app-smart',
  templateUrl: './smart.component.html',
  styleUrls: ['./smart.component.css']
})
export class SmartComponent implements OnInit {

  number = 1

// totalCost : number;

  isChecked : boolean = false
    base64Image: any="";
    burgerData: any = {};
    radioStatus:  boolean=false;
  
    disable1: boolean= false;
    disable2: boolean= false;
  radioButtonVariable: any;
  checkCalories:number=0;
  radioCalories: number=0;
  totalCalories: number=0;
  
  checkCost:number=0;
  radioCost: number=0;
  totalCost: number=0;
  radioCost1: number=0;

    constructor(private ds:DataService,private sanitizer:DomSanitizer) {
  
      }
    transform(){
      return this.sanitizer.bypassSecurityTrustResourceUrl(this.base64Image);
  }
  ngOnInit(): void {
    this.getBurgerData() 
}
  getBurgerData(){
    this.ds.getFood().subscribe(res=>{
 this.burgerData = res;
this.base64Image= this.burgerData.foodimage; 
    })
  }

  addStandardtoppings(event: any, NewCalories: any, NewCost: any, check: string){    
if(check =="first"){
  if(event.checked === true ){
this.checkCalories = parseInt(NewCalories)+ this.checkCalories ;
this.totalCalories =  this.checkCalories + this.radioCalories 
this.checkCost = parseInt(NewCost)+ this.checkCost ;
this.totalCost =  this.checkCost + this.radioCost + this.radioCost1
  }
  else{
    this.totalCalories= this.totalCalories-parseInt(NewCalories)
    this.checkCalories -=parseInt(NewCalories)
    this.totalCost= this.totalCost-parseInt(NewCost)
    this.checkCost -=parseInt(NewCost)
  }
}   
 if(check=="second"){
  this.radioCalories = 0; 
  this.radioCost=0;
   this.radioCalories=parseInt(NewCalories) 
  this.totalCalories = this.radioCalories  +this.checkCalories
  this.radioCost=parseInt(NewCost) 
  this.totalCost = this.radioCost  +this.checkCost + this.radioCost1
 }
 if(check=="third"){
  this.radioCost1=0;
  this.radioCost1=parseInt(NewCost) 
  this.totalCost = this.radioCost1  +this.checkCost+this.radioCost
 }

  }


}