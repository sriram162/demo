import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

import { DataService } from '../data.service';
@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {
calories="500 cal"
price="250 rupees/-"
public results:any=[]
 // price:any;
  //colories:any
//result:any
data: any=[]
  base64Image: any;
  
 
  constructor(private ds:DataService,private sanitizer:DomSanitizer) { 
   
    
    

  }


  ngOnInit():void{
   
   this.ds.getFood().subscribe((foodmenu)=>{
      this.results=foodmenu
console.log(this.results)
console.log(this.results.foodname)
this.base64Image= this.results.foodimage
    console.log(this.base64Image);
    })
    
  }
  transform(){
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.base64Image);
}

}
