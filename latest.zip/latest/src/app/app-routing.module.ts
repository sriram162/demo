import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import{RadioComponent}from'./radio/radio.component';
import {StudentmodalComponent}from'./studentmodal/studentmodal.component';
import{PgnotfoundComponent}from'./pgnotfound/pgnotfound.component';
import{FooterComponent}from'./footer/footer.component';
import{AdmissionsComponent}from'./admissions/admissions.component';
import{BodyComponent}from'./body/body.component';
import{CoursedetailsComponent}from'./coursedetails/coursedetails.component';
import{CoursedurationComponent}from'./courseduration/courseduration.component';
import{CoursefeeComponent}from'./coursefee/coursefee.component';
import{HeaderComponent}from'./header/header.component';
import{ParentsComponent}from'./parents/parents.component';


const routes: Routes = [

 

 //{path:'',redirectTo:'AdmissionsComponent',pathMatch:'full'},
 //{path:'',component:AdmissionsComponent},
 {path:'parentportal',component:ParentsComponent},
 {path:'admissions',component:AdmissionsComponent},
 {path:'studentportal',component:StudentmodalComponent},
 {path:'radio',component:RadioComponent},
 {path:'footer',component:FooterComponent},

 {
   path:"faculty",loadChildren:()=>
   import("./faculty/faculty.module").then(m=>m.FacultyModule),
 },

 {
  path:"courses",loadChildren:()=>
  import("./courses/courses.module").then(m=>m.CoursesModule),
},
 
 {path:'coursedetails',component:CoursedetailsComponent,
 children:[
   {path:'duration',component:CoursedurationComponent},
  {path:'fee',component:CoursefeeComponent},
 ]
},
 //{path:"**",component:PgnotfoundComponent},
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
