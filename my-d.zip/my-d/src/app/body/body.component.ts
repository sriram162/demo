import { formatCurrency } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
  tableView : any= [];
  constructor() { 
    console.log(this.tableView)
  }


  ngOnInit(): void {
  }
  
  displaydetails(myform:NgForm){
   //if(!myform.valid){
    // return
  // }
    
this.tableView.push(myform.value);


myform.reset();


  }
}
