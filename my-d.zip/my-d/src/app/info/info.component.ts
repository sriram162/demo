import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {

public results:any=[]
  price:any;
  colories:any
//result:any
  updatePrice(){

  }
  updateCalories(){

  }
  constructor(private ds:DataService) { }

  ngOnInit():void{
   
    this.ds.getFood().subscribe((data)=>{
      this.results=data
      debugger
console.log(this.results['foodname']);
    })
    
  }

}
