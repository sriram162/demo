import { Component, OnInit } from '@angular/core';
import{FormGroup,FormControl,Validators}from'@angular/forms'

@Component({
  selector: 'app-studentmodal',
  templateUrl: './studentmodal.component.html',
  styleUrls: ['./studentmodal.component.css']
})
export class StudentmodalComponent  {
  tableView:any=[]
userForm:any =new FormGroup({
name:new FormControl('',[Validators.required,Validators.minLength(2),Validators.maxLength(15)]),
email:new FormControl('',[Validators.required,Validators.minLength(2)]),
street:new FormControl('',[Validators.required,Validators.minLength(2)]),
city:new FormControl('',[Validators.required,Validators.minLength(2)]),
pincode:new FormControl('',[Validators.required,Validators.minLength(2)]),
  });
  onSubmit(){

    console.log(this.userForm.value);
    this.tableView.push(this.userForm.value);
    console.log("tabledata",this.tableView);
    this.userForm.reset()
  
  }

}
