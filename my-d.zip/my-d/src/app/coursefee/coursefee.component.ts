import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-coursefee',
  templateUrl: './coursefee.component.html',
  styleUrls: ['./coursefee.component.css']
})
export class CoursefeeComponent implements OnInit {
  onChangeFah(Cel:any,Fah:any){
Fah.value=(Cel.value*(9/5)+32).toFixed(1);
//console.log(Fah.value);
  }
  onChangeCel(Fah:any,Cel:any){
Cel.value=((Fah.value-32)*(5/9)).toFixed(1);
//console.log(Fah,Cel);
}
  constructor() { }



  ngOnInit(): void {
  }
}
