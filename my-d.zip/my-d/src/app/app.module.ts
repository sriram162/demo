import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import {ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BodyComponent } from './body/body.component';
import { StudentmodalComponent } from './studentmodal/studentmodal.component';
//import { ParentComponent } from './parent/parent.component';
//import { CustomdirDirective } from './customdir.directive';
import { RadioComponent } from './radio/radio.component';
import { InfoComponent } from './info/info.component';
//import { DetailsComponent } from './details/details.component';
import { HttpClientModule } from '@angular/common/http';
import { DataService } from './data.service';
import { CustomDirective } from './custom.directive';
import { FilterPipe } from './filter.pipe';
import { PgnotfoundComponent } from './pgnotfound/pgnotfound.component';
import { AdmissionsComponent } from './admissions/admissions.component';
import { ParentsComponent } from './parents/parents.component';
import { CoursedurationComponent } from './courseduration/courseduration.component';
import { CoursefeeComponent } from './coursefee/coursefee.component';
import { CoursedetailsComponent } from './coursedetails/coursedetails.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    StudentmodalComponent,
    //ParentComponent,
    //CustomdirDirective,
    RadioComponent,
    InfoComponent,
    CustomDirective,
    FilterPipe,
    PgnotfoundComponent,
    AdmissionsComponent,
    ParentsComponent,
    CoursedurationComponent,
    CoursefeeComponent,
    CoursedetailsComponent,
    //DetailsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
