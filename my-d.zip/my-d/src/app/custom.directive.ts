import { Directive,ElementRef, HostListener, Input, OnInit, SimpleChanges } from '@angular/core';

@Directive({selector: '[appCustom]'})
export class CustomDirective implements OnInit {

@Input() defaultColor: any;
@Input('appCustom') highlightColor: any;
constructor(private el: ElementRef) {
}
ngOnInit() {
  if (this.highlightColor == undefined) {
      this.highlight('null')

  }
}
ngOnChanges(changes: SimpleChanges) {


  this.highlight(changes.highlightColor.currentValue)


}
highlight(color: string) {
  this.el.nativeElement.style.backgroundColor = color;
}

}
