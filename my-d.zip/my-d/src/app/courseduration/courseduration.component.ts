import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courseduration',
  templateUrl: './courseduration.component.html',
  styleUrls: ['./courseduration.component.css']
})
export class CoursedurationComponent implements OnInit {
  Fahrenheit: any
  Celsius: any
  constructor() { }

  ngOnInit(): void {
  }
  onSearchChange(event:any, temparature:any) {
    if (event!=null){
    if (temparature === 'Celsius') {
      console.log("checking....", event);

      let temp = (parseInt(event) - 32) / 1.8
      this.Fahrenheit = temp.toFixed(2);
    }
    else {
      let temp = (parseInt(event) * 32) + 1.8;
      this.Celsius = temp.toFixed(2);
    }
  }
}
}
