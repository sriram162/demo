import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }

getFood(){
  console.log(this.http.get('assets/Assignment.json'));
  return this.http.get('assets/Assignment.json');
}
  
}
